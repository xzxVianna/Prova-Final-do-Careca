package sample;

public class MainProduto {


    public static void main(String[] args) {
        class Produto {

            public String nome;
            public double Preco;

            Produto produto = new Produto();

            public void setPreco(double preco) {
                Preco = preco;
            }

            public void setNome(String nome) {
                this.nome = nome;
            }

            public String getNome() {
                return nome;
            }

            public double getPreco() {
                return Preco;
            }
            public void setProduto(String nome, double preco){
                produto.setNome("Arroz");
                produto.setPreco(10);

            }

            @Override
            public String toString() {
                return "Produto{" +
                        "nome='" + nome + '\'' +
                        ", Preco=" + Preco +
                        '}';
            }
            System.out.println(Produto);


           // Produto produto = new Produto();
       // produto.setNome("Arroz");
        //produto.setPreco(7);

        }

    }

}
